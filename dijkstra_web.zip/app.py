from flask import Flask, render_template, request
import osmnx as ox
import networkx as nx
from geopy.geocoders import Nominatim
import folium

app = Flask(__name__)
geolocator = Nominatim(user_agent="dijkstra_map_app")

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        origin = request.form['origin']
        destination = request.form['destination']

        # Geocodifica os endereços
        try:
            origin_loc = geolocator.geocode(origin)
            dest_loc = geolocator.geocode(destination)

            if not origin_loc or not dest_loc:
                return "Erro ao localizar endereços."

            orig_point = (origin_loc.latitude, origin_loc.longitude)
            dest_point = (dest_loc.latitude, dest_loc.longitude)

            # Baixa o grafo OSM da região (5km de raio)
            G = ox.graph_from_point(orig_point, dist=5000, network_type='walk')

            # Encontra os nós mais próximos
            orig_node = ox.nearest_nodes(G, X=orig_point[1], Y=orig_point[0])
            dest_node = ox.nearest_nodes(G, X=dest_point[1], Y=dest_point[0])

            # Calcula o caminho mais curto
            route = nx.shortest_path(G, orig_node, dest_node, weight='length')

            # Cria o mapa
            m = ox.plot_route_folium(G, route, route_color='blue', zoom=14)
            folium.Marker(orig_point, tooltip="Origem").add_to(m)
            folium.Marker(dest_point, tooltip="Destino").add_to(m)

            m.save('templates/map.html')
            return render_template('map.html')

        except Exception as e:
            return f"Ocorreu um erro: {e}"

    return render_template('index.html')
